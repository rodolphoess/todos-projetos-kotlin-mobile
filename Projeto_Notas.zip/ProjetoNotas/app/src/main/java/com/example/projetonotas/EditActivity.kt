package com.example.projetonotas

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_edit.*
import java.io.Serializable

class EditActivity : AppCompatActivity() {

    private var edtNota: EditText? = null
    private var nota: Nota? = null
    private var posicao: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        edtNota = findViewById(R.id.edt_nota)

        nota = intent.getSerializableExtra("nota") as Nota?
        posicao = intent.getIntExtra("posicao",-1)

        if (nota != null){
            edtNota?.setText(nota?.conteudo)
        }

    }


    fun gravar(view: View){
        var conteudo: String =  edtNota?.text.toString()

        if (nota == null){


            NotaNameDialog.show(supportFragmentManager,object :NotaNameDialog.OnNoteNameSetListener{
                override fun onNoteNameSet(noteName: String) {
                    salvarConteudoNota(noteName,conteudo)
                }
            })
        }else{
            var titulo = nota?.titulo.toString()
            var conteudo = edtNota?.text.toString()

            salvarConteudoNota(titulo,conteudo)
        }
    }


    fun salvarConteudoNota(titulo: String, conteudo: String){

        if (nota == null){
            nota = Nota(titulo,conteudo)
            var i = Intent()
            i.putExtra("nota",nota)
            setResult(RESULT_OK,i)
            finish()

        }else{
            nota = Nota(titulo,conteudo)

            var i = Intent()
            i.putExtra("nota",nota)
            i.putExtra("posicao",posicao)
            setResult(RESULT_OK,i)
            finish()
        }


    }



    fun cancelar(view: View) {
        setResult(RESULT_CANCELED)
        finish()
    }


}
