package com.example.projetonotas

import java.io.Serializable


data class Nota(var titulo: String, var conteudo: String) : Serializable{


    override fun toString(): String {
        return this.titulo
    }
}