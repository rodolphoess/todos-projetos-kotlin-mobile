package ufrn.imd.projetomapsmakerkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(),
    OnMapReadyCallback,
    GoogleMap.OnMapClickListener,
    GoogleMap.OnMarkerDragListener,
    GoogleMap.OnMarkerClickListener
{



    private lateinit var mMap: GoogleMap

    private var markerId: Int = 0


    private val colors = floatArrayOf(
        BitmapDescriptorFactory.HUE_BLUE,
        BitmapDescriptorFactory.HUE_GREEN,
        BitmapDescriptorFactory.HUE_RED,
        BitmapDescriptorFactory.HUE_ORANGE
    )

    private var colorIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }


    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.setOnMapClickListener(this)

//        // Add a marker in Sydney and move the camera
//        val sydney = LatLng(-34.0, 151.0)
//        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
    }


    override fun onMapClick(latLng: LatLng) {
        val options = MarkerOptions()
        markerId++
        options.position(latLng)
            .title("Marcador $markerId")
            .snippet("Detalhes do Marcador $markerId")
//                            .icon(BitmapDescriptorFactory.
//                                    fromResource(android.R.drawable.star_on));
            .icon(BitmapDescriptorFactory.defaultMarker(colors[colorIndex]))
            .draggable(true)

        colorIndex = (colorIndex + 1) % colors.size

        mMap.addMarker(options)

    }


    override fun onMarkerClick(marker: Marker?): Boolean {
        Toast.makeText(this, "Você clicou no " + marker?.getTitle(), Toast.LENGTH_SHORT).show()

        return false
    }

    override fun onMarkerDragEnd(p0: Marker?) {

    }

    override fun onMarkerDragStart(p0: Marker?) {

    }

    override fun onMarkerDrag(marker: Marker?) {
        Toast.makeText(this, "" + marker?.getPosition(), Toast.LENGTH_SHORT).show()
    }



}
