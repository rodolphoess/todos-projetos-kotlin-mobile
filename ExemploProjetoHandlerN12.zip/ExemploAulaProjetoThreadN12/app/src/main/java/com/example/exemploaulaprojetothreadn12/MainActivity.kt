package com.example.exemploaulaprojetothreadn12

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.os.SystemClock
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val handler:Handler = Handler()

    var myHandler:MyHandler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        myHandler = MyHandler(btnProcessar,txtTexto)

//        object : Thread(){
//
//            override fun run() {
//                txtTexto.text = "Texto alterado - 1"
//            }
//        }.start()

//        Thread{
//            txtTexto.text = "Texto alterado - 2"
//        }.start()

//        var handler = Handler()
//
//        Thread{
//            handler.post { txtTexto.text = "Texto alterado - 3" }
//        }.start()

        //runOnUiThread { txtTexto.text = "Texto alterado - 4" }

    }

    fun processar(v: View){

        txtTexto.text = "Processando..."
        btnProcessar.isEnabled = false
        executaAlgoDemorado()

    }

    fun executaAlgoDemorado(){

        Thread{
            SystemClock.sleep(5000)

//            runOnUiThread {
//                txtTexto.text = "Processamento finalizado!"
//                btnProcessar.isEnabled = true
//            }

//            handler.post {
//                txtTexto.text = "Processamento finalizado!"
//                btnProcessar.isEnabled = true
//            }

            var msg:Message = Message.obtain()
            msg.what = 100
            myHandler?.sendMessage(msg)

        }.start()

    }

}





























