package com.example.exemploaulaprojetothreadn12

import android.os.Handler
import android.os.Message
import android.widget.Button
import android.widget.TextView

class MyHandler(val button:Button, val textView: TextView): Handler() {

    override fun handleMessage(msg: Message?) {
        super.handleMessage(msg)

        if(msg?.what == 100){
            textView.text = "Processamento finalizado!"
            button.isEnabled = true
        }
    }
}