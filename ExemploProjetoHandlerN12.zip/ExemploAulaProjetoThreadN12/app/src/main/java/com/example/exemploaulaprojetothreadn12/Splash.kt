package com.example.exemploaulaprojetothreadn12

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock

class Splash : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Thread{
            SystemClock.sleep(3000)

            var intent = Intent(applicationContext,MainActivity::class.java)
            startActivity(intent)

            finish()
        }.start()
    }
}
