package com.example.projeto2broadcas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class ToasReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        var msg = intent.getStringExtra("msg")
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()

        }
    }

