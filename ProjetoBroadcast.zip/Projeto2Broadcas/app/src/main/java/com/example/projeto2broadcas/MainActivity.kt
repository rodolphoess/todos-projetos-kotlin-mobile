package com.example.projeto2broadcas

import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {

    private var receiver:ToasReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        receiver = ToasReceiver()
        var intentFilter = IntentFilter()

        intentFilter.addAction("br.ufrn.imd.android.broadcast.TOAST");
        registerReceiver(receiver,intentFilter)
    }

    fun send(view: View) {
        var intent = Intent("br.ufrn.imd.android.broadcast.TOAST")
        intent.putExtra("msg","Texto enviado via Broadcast")
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        if(receiver != null){
            unregisterReceiver(receiver)
        }
        super.onDestroy()
        
    }
}
