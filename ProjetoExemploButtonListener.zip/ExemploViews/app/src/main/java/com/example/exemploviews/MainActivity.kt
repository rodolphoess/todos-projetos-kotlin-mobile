package com.example.exemploviews

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), OnClickListener {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        button1.setOnClickListener {
//            Toast.makeText(this, "Botão 1 clicado!", Toast.LENGTH_LONG).show()
//        }
//
//        button2.setOnClickListener {
//            Toast.makeText(this, "Botão 2 clicado!", Toast.LENGTH_LONG).show()
//        }

        button1.setOnClickListener(this)
        button2.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        if(v?.id == R.id.button1){
            Toast.makeText(this, "Botão 1 clicado!", Toast.LENGTH_LONG).show()
        }else if(v?.id == R.id.button2){
            Toast.makeText(this, "Botão 2 clicado!", Toast.LENGTH_LONG).show()
        }
    }

    fun enviar(v: View){
        // Códigos aqui
    }



}
