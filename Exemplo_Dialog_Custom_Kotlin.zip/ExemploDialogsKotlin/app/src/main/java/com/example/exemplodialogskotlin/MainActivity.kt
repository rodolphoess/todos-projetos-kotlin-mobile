package com.example.exemplodialogskotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.dialog_my_edit.*
import org.w3c.dom.Text


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }



    fun openEditDialog(view: View) {
        MyEditDialog.show(supportFragmentManager, object : MyEditDialog.OnTextListener {
            override fun onSetTExt(text: String) {
                Toast.makeText(this@MainActivity, "Texto: $text", Toast.LENGTH_SHORT).show()
            }
        })
    }


}
