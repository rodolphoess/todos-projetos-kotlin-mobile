package com.example.projetospinnern12

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment


class ExitDialog : DialogFragment(), DialogInterface.OnClickListener {


    private var myListener: ExitListener? = null

    override fun onAttach(context: Context?) {
        super.onAttach(context)

        super.onAttach(context)

        if(!(context is ExitListener)){
            throw Exception("Não é um OnInvertListener")
        }

        myListener = context as ExitListener
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        var builder = AlertDialog.Builder(requireContext())

        builder.setTitle("Meu AlertDialog")
        builder.setMessage("Para sair da aplicação clique em 'Sim'" +
                "\nPara permanecer clique em 'Não'")
        builder.setPositiveButton("Sim",this)
        builder.setNegativeButton("Não",this)


        return builder.create()
    }

    override fun onClick(dialog: DialogInterface?, which: Int) {

        if (which == DialogInterface.BUTTON_POSITIVE && myListener != null) {
            myListener?.onExit()
        }

    }


    interface ExitListener{
        fun onExit():Unit
    }

}