package com.example.recyclerviewn12

data class Message(var title: String, var text: String)

