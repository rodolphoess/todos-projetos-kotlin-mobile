package com.example.projetoautenticaon12

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth


class TelaPrincipalActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_principal)

        auth = FirebaseAuth.getInstance()
    }

    fun logout(view: View) {

        auth.signOut()
        finish()

    }
}
