package com.example.projetobroadcastatividadeairplane

import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    private var receiver: AirPlaneReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        receiver = AirPlaneReceiver()
        var intentFilter = IntentFilter()

        intentFilter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)

        registerReceiver(receiver,intentFilter)
    }

    override fun onDestroy() {
        if(receiver != null){
            unregisterReceiver(receiver)
        }
        super.onDestroy()
    }
}
