package com.example.projetoautenticaon12

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class CadastrarActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastrar)


    }


    fun cadastrarUsuario(view: View){



    }
}
