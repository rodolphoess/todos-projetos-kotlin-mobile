package ufrn.imd.exemplofirebasecrudn12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.view.get
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    val db = FirebaseFirestore.getInstance()

    var listUsers = arrayListOf<User>()

    lateinit var user: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView.onItemClickListener = AdapterView.OnItemClickListener {
                parent, view, position, id ->
            user = listUsers[position]
            edt_nome.setText(user.nome)
            edt_email.setText(user.email)

        }

        btn_editar.setOnClickListener {
            val u = mapOf(
                "nome" to edt_nome.text.toString(),
                "email" to edt_email.text.toString()
            )

            db.collection("users").document(user.id)
                .update(u)
                .addOnSuccessListener {
                    Toast.makeText(
                    this,
                    "Editado com sucesso!",
                    Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {e ->
                    Toast.makeText(
                        this,
                        "Erro ao Editar: $e",
                        Toast.LENGTH_LONG).show()
                }

            lerDados()
        }

        btn_excluir.setOnClickListener {
            db.collection("users").document(user.id)
                .delete()
                .addOnSuccessListener {
                    Toast.makeText(
                        this,
                        "Deletado com sucesso!",
                        Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {e ->
                    Toast.makeText(
                        this,
                        "Erro ao Deletar: $e",
                        Toast.LENGTH_LONG).show()
                }

            lerDados()


        }

        btn_listar.setOnClickListener {
            lerDados()
        }

        btn_cadastrar.setOnClickListener {

            val user = hashMapOf(
                "nome" to edt_nome.text.toString(),
                "email" to edt_email.text.toString()
            )

            db.collection("users")
                .add(user)
                .addOnSuccessListener { docref ->
                    Toast.makeText(this,
                        "Adicionado com Sucesso: ${docref.id}", Toast.LENGTH_LONG)
                        .show()
                }
                .addOnFailureListener{
                        e ->
                    Toast.makeText(this,
                        "Erro ao adicionar: $e", Toast.LENGTH_LONG)
                        .show()
                }

            edt_nome.text.clear()
            edt_email.text.clear()
            edt_nome.requestFocus()

            lerDados()

        }
    }


    fun lerDados(){

        listUsers.clear()

        db.collection("users")
            .get()
            .addOnSuccessListener {result ->

                for(doc in result){
                    var jo = JSONObject(doc.data)
                    var user = User(
                        doc.id,
                        jo.getString("nome"),
                        jo.getString("email")
                    )
                    listUsers.add(user)
                }

                listView.adapter =
                    ArrayAdapter(this,android.R.layout.simple_list_item_1,
                        listUsers)

            }
            .addOnFailureListener{e->
                Toast.makeText(this, "Erro: $e",Toast.LENGTH_LONG).show()

            }

    }
}
















