package ufrn.imd.exemplofirebasecrudn12

data class User (var id: String, var nome: String, var email: String){

    override fun toString(): String {
        return  "$nome ($email)"
    }
}