package com.example.projetonotas

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_nota.view.*


class NotaAdapter(
    private val notas: List<Nota>,
    private val callback: (Nota,Int) -> Unit,
    private val callbackLong:(Int)-> Boolean):RecyclerView.Adapter<NotaAdapter.VH>() {

    override fun getItemCount(): Int = notas.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_nota,parent, false)

        val vh = VH(v)

        vh.itemView.setOnClickListener {
            val nota = notas[vh.adapterPosition]
            callback(nota,vh.adapterPosition)
        }

        vh.itemView.setOnLongClickListener {
            callbackLong(vh.adapterPosition)
        }
        return vh
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val nota = notas[position]
        holder.txtTitle.text = nota.titulo
    }

    class  VH(itemView: View): RecyclerView.ViewHolder(itemView){
        val txtTitle: TextView = itemView.txtTitulo
    }
}