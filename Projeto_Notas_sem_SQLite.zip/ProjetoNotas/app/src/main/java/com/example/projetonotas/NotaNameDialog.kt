package com.example.projetonotas

import android.app.AlertDialog
import android.app.Dialog

import android.os.Bundle
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager


class NotaNameDialog : DialogFragment() {


    private var listener: OnNoteNameSetListener? = null

    private var edtNoteName: EditText? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireActivity())

        builder.setTitle(R.string.dialog_title)
        builder.setPositiveButton(R.string.dialog_btn_ok) { dialog, which ->
            if (listener != null) {
                val noteName = edtNoteName!!.text.toString()
                listener!!.onNoteNameSet(noteName)
            }
        }



        val view = requireActivity().layoutInflater.inflate(R.layout.dialog_nota_name, null)
        edtNoteName = view.findViewById(R.id.edt_notaname)

        builder.setView(view)

        return builder.create()
    }

    interface OnNoteNameSetListener {
        fun onNoteNameSet(noteName: String)
    }

    companion object {

        // Exibe o dialog
        fun show(fm: FragmentManager, listener: OnNoteNameSetListener) {
            val dialog = NotaNameDialog()
            dialog.listener = listener
            dialog.show(fm, "noteNameDialog")
        }
    }
}
