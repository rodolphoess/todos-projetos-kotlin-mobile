package com.example.projetonotas

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_list.*

class ListActivity : AppCompatActivity() {

    private  var notas = mutableListOf<Nota>()
    private var adapter = NotaAdapter(notas,this::onNotaItemClick, this::onNotaItemLongClick)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        initRecyclerView()
        //addNotas()


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.actions, menu)
        return true
        //return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if(item.itemId == R.id.nota_add){
            var intent = Intent(this,EditActivity::class.java)
            startActivityForResult(intent,0)
            return true
        }

        return super.onOptionsItemSelected(item)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)



        if(requestCode == 0 && resultCode == Activity.RESULT_OK){

            var nota = data?.getSerializableExtra("nota") as Nota
            notas.add(nota)

            adapter.notifyItemInserted(notas.lastIndex)
        }

        if (requestCode == 1 && resultCode == Activity.RESULT_OK){

            var nota = data?.getSerializableExtra("nota") as Nota
            var posicao = data?.getIntExtra("posicao",-1)

            notas[posicao] = nota

            adapter.notifyDataSetChanged()
        }


    }

    fun onNotaItemClick(nota: Nota, posicao: Int){

        var intent = Intent(this,EditActivity::class.java)

        intent.putExtra("nota",nota)
        intent.putExtra("posicao",posicao)



        startActivityForResult(intent,1)

    }

    fun onNotaItemLongClick(posicao: Int):Boolean{

        notas.removeAt(posicao)
        adapter.notifyItemRemoved(posicao)

        return true
    }

    fun initRecyclerView(){

        rvNotas.adapter = adapter

        val layoutMAnager = LinearLayoutManager(this)

        rvNotas.layoutManager = layoutMAnager

    }


//    fun addNotas(){
//
//        notas.add(Nota("Nota 1", "Conteúdo Teste"))
//        notas.add(Nota("Nota 2", "Conteúdo Teste"))
//        notas.add(Nota("Nota 3", "Conteúdo Teste"))
//        notas.add(Nota("Nota 4", "Conteúdo Teste"))
//        notas.add(Nota("Nota 5", "Conteúdo Teste"))
//
//        adapter.notifyItemInserted(notas.lastIndex)
//
//    }
}
