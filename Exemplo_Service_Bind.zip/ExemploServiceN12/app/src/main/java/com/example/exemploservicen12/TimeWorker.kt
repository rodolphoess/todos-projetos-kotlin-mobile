package com.example.exemploservicen12

import android.os.SystemClock
import android.util.Log

class TimeWorker: Runnable {

    @Volatile
    private var running: Boolean = false
    private var seconds: Int = 0

    override fun run() {
        running = true

        while (running){
            //seconds++
            incrementSeconds()
            Log.i("myapp", "Segundos = $seconds")
            SystemClock.sleep(1000)
        }
    }

    @Synchronized
    private fun incrementSeconds(){
        seconds++
    }

    @Synchronized
    fun getSeconds():Int{
        return seconds
    }

    fun stop(){
        running = false
    }
}