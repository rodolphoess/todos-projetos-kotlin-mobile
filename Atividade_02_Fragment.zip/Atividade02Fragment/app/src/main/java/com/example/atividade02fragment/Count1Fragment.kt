package com.example.atividade02fragment

import android.annotation.SuppressLint
import android.os.Parcel
import android.os.Parcelable

class Count1Fragment() : CountFragment() {


    override val fragmentView: Int
        get() = R.layout.fragment_count1



}