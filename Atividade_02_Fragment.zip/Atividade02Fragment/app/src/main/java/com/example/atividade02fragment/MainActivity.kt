package com.example.atividade02fragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity(), ButtonFragment.IncrementListener {


    private var count1Fragment: CountFragment? = null
    private var count2Fragment: CountFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val fm = supportFragmentManager
        val ft = fm.beginTransaction()



        count1Fragment = fm.findFragmentById(R.id.lay_count1) as CountFragment?
        if (count1Fragment == null) {
            count1Fragment = Count1Fragment()
            ft.add(R.id.lay_count1, count1Fragment as Count1Fragment, "count1Fragment")
        }



        count2Fragment = fm.findFragmentById(R.id.lay_count2) as CountFragment?
        if (count2Fragment == null) {
            count2Fragment = Count2Fragment()
            ft.add(R.id.lay_count2, count2Fragment as Count2Fragment, "count2Fragment")
        }


        var buttonFragment: ButtonFragment? = fm.findFragmentById(R.id.lay_button) as ButtonFragment?
        if (buttonFragment == null) {
            buttonFragment = ButtonFragment()
            ft.add(R.id.lay_button, buttonFragment, "buttonFragment")
        }


        ft.commit()
    }


    override fun increment() {

        count1Fragment?.increment()
        count2Fragment?.increment()

    }
}
