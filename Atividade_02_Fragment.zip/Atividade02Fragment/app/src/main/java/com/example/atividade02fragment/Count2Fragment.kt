package com.example.atividade02fragment



class Count2Fragment : CountFragment() {

    override val fragmentView: Int
        get() = R.layout.fragment_count2
}