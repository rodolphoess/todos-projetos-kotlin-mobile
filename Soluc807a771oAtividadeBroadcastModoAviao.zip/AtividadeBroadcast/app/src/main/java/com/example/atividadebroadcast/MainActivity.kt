package com.example.atividadebroadcast

import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    var receiver: ModoAviaoReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        receiver = ModoAviaoReceiver()
        var intentFilter = IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        registerReceiver(receiver, intentFilter)

    }


    override fun onDestroy() {

        if(receiver != null){
            unregisterReceiver(receiver)
        }
        super.onDestroy()
    }
}
