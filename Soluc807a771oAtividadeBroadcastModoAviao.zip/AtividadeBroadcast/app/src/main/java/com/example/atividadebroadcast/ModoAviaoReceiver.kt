package com.example.atividadebroadcast

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class ModoAviaoReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        var on = intent.getBooleanExtra("state", false)

        if (on){
            Toast.makeText(context, "Modo Avião Ligado!", Toast.LENGTH_LONG).show()
        }else{
            Toast.makeText(context, "Modo Avião Desligado!", Toast.LENGTH_LONG).show()
        }
    }
}
