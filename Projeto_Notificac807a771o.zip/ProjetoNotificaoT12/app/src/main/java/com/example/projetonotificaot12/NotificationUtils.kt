package com.example.projetonotificaot12

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationUtils {
    val CHANNEL_ID = "default"

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotifictionChannel(context: Context){
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE)
                 as NotificationManager

        val channelName = "Padrão"
        val channelDescription = "Canal padrão de Notificações"

        val channel = NotificationChannel(
            CHANNEL_ID,
            channelName,
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = channelDescription
            enableLights(true)
            lightColor = Color.GREEN
            vibrationPattern =
                longArrayOf(100,200,300,400,500,400,300,200,400)
        }
        notificationManager.createNotificationChannel(channel)
    }

    fun notificationSimple(context: Context){

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            createNotifictionChannel(context)
        }

        val notificationBuilder =
            NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_favorite)
                .setContentTitle("Minha Notificação")
                .setContentText("Essa é minha notificação")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setColor(ActivityCompat.getColor(context,R.color.colorAccent))
                .setDefaults(Notification.DEFAULT_ALL)
        val notificationManager =
            NotificationManagerCompat.from(context)
        notificationManager.notify(1,notificationBuilder.build())

    }

    fun getContentIntent(context: Context):PendingIntent?{
        val intent = Intent(context, DetailsActivity::class.java).apply {
            putExtra(DetailsActivity.EXTRA_MESSAGE, "Via notificação")
        }

        return PendingIntent.getActivity(context,0,intent,0)
//        return TaskStackBuilder.create(context)
//            .addNextIntentWithParentStack(intent)
//            .getPendingIntent(1,PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun notificationWithAction(context: Context){

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            createNotifictionChannel(context)
        }

        val notificationBuilder =
            NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_favorite)
                .setContentTitle("Minha Notificação Action")
                .setContentText("Essa é minha notificação Action")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setColor(ActivityCompat.getColor(context,R.color.colorAccent))
                .setDefaults(Notification.DEFAULT_ALL)
                .setContentIntent(getContentIntent(context))
                .setAutoCancel(true)

        val notificationManager =
            NotificationManagerCompat.from(context)
        notificationManager.notify(2,notificationBuilder.build())
    }


}









