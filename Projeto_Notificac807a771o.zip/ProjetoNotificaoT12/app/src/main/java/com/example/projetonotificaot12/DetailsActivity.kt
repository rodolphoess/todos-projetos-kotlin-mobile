package com.example.projetonotificaot12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_details.*

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        txtMessage.text = intent.getStringExtra(EXTRA_MESSAGE)
    }

    companion object{
        val EXTRA_MESSAGE = "message"
    }
}
