package android.imd

import android.app.SearchManager
import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ListView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout

class MainActivity : AppCompatActivity(), PlanetAdapter.OnItemClickListener{

    private var drawerLayout: DrawerLayout? = null
    private var drawerList: ListView? = null
    private var planetSelected: Planet? = null
    private var drawerToggle: ActionBarDrawerToggle? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        drawerLayout = findViewById(R.id.drawer_layout)
        drawerList= findViewById(R.id.left_drawer)

        drawerList?.adapter= PlanetAdapter(this, this)

        if (supportActionBar != null) {
            supportActionBar!!.setDisplayHomeAsUpEnabled(true);
        }

        drawerToggle = object :
            ActionBarDrawerToggle(this, drawerLayout, R.string.drawer_open, R.string.drawer_close) {
            override fun onDrawerOpened(drawerView: View) {
                setTitle(R.string.title_choose)
                invalidateOptionsMenu()
            }

            override fun onDrawerClosed(drawerView: View) {
                if (planetSelected != null) {
                    setTitle(planetSelected?.name)
                } else {

                    setTitle(R.string.app_name)
                }

                invalidateOptionsMenu()
            }
        }

        if (savedInstanceState == null) {
            selectItem(null)
        } else {
            planetSelected = savedInstanceState.getParcelable("planet") as Planet?
            selectItem(planetSelected)
        }

        drawerLayout?.addDrawerListener(drawerToggle!!)
    }

    override fun onClick(planet: Planet) {
        selectItem(planet)
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val drawerOpen = drawerLayout?.isDrawerOpen(drawerList as View)
        val searchMenu = menu.findItem(R.id.action_search)

        if(planetSelected!=null){
            searchMenu.isVisible= true
        }else if(drawerOpen== true){
            searchMenu.isVisible= false
        }else{
            searchMenu.isVisible= false
        }

        return super.onPrepareOptionsMenu(menu)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.action, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (drawerToggle?.onOptionsItemSelected(item)!!) {
            return true
        }

        if (item.itemId == R.id.action_search) {
            val intent = Intent(Intent.ACTION_WEB_SEARCH)
            intent.putExtra(SearchManager.QUERY, "Planeta: " + planetSelected?.name)
            startActivity(intent)

            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun selectItem(planet: Planet?) {
        if (planet != null) {
            this.planetSelected = planet
            val fragment = PlanetFragment.newInstance(planet)
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.content_frame, fragment)
            transaction.commit()
            setTitle(planet.name)

        }

        drawerLayout?.closeDrawer(drawerList!!)

    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState.putParcelable("planet", planetSelected)
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        drawerToggle?.syncState()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        drawerToggle?.onConfigurationChanged(newConfig)
    }

}
