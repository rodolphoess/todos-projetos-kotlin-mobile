package android.imd

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment

class PlanetFragment() : Fragment(){

    private var planet: Planet? = null

    companion object{
        fun newInstance(planet: Planet): PlanetFragment{
            var fragment: PlanetFragment= PlanetFragment()
            fragment.planet= planet
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance= true
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var view: View= inflater.inflate(R.layout.fragment_planet, container, false)
        var imageView : ImageView = view.findViewById(R.id.image)
        imageView.setImageResource(planet?.imageId!!)
        activity?.title = planet?.name

        return view
    }
}