package com.example.projetosqlite.repository.sqlite

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.projetonotassqlite.model.Nota



class SQLiteRepository(ctx: Context): NotaRepository {

    private  val helper: NotaSqlHelper = NotaSqlHelper(ctx)

    private fun insert(nota: Nota){

        val db = helper.writableDatabase

        val cv = ContentValues().apply {
            put(COLUMN_TITLE, nota.titulo)
            put(COLUMN_CONTENT, nota.conteudo)
        }

        val id = db.insert(TABLE_NAME, null, cv)
        if (id != -1L){
            nota.id = id
        }
        db.close()
    }

    private fun update(nota: Nota){
        val db = helper.writableDatabase

        val cv = ContentValues().apply {
            put(COLUMN_TITLE, nota.titulo)
            put(COLUMN_CONTENT, nota.conteudo)
        }

        db.update(
            TABLE_NAME,
            cv,
            "$COLUMN_ID = ? ",
            arrayOf(nota.id.toString())
        )

        db.close()

    }


    override fun save(nota: Nota) {
        if (nota.id == 0L){
            insert(nota)
        }else{
            update(nota)
        }
    }

    override fun remove(nota: Nota) {
        val db = helper.writableDatabase

        db.delete(
            TABLE_NAME,
            "$COLUMN_ID = ? ",
            arrayOf(nota.id.toString())
        )

        db.close()
    }


    override  fun list(callbacks: (MutableList<Nota>)->Unit){

        var sql = "SELECT * FROM $TABLE_NAME"
        var args: Array<String>? = null

        sql += " ORDER BY $COLUMN_ID"
        val db = helper.readableDatabase
        val cursor = db.rawQuery(sql, args)
        val notas = ArrayList<Nota>()
        while (cursor.moveToNext()){
            val produto = notaFromCursor(cursor)
            notas.add(produto)
        }
        cursor.close()
        db.close()

        callbacks(notas)
    }


    private fun notaFromCursor(cursor: Cursor): Nota {
        val id = cursor.getLong(cursor.getColumnIndex(COLUMN_ID))
        val title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE))
        val content = cursor.getString(cursor.getColumnIndex(COLUMN_CONTENT))

        return Nota(id, title, content)
    }

}