package com.example.projetonotassqlite.model

import java.io.Serializable


data class Nota(var titulo: String, var conteudo: String) : Serializable{

    var id: Long = 0

    constructor(id:Long,titulo: String,conteudo: String) : this(titulo, conteudo) {
        this.id = id
    }

    override fun toString(): String {
        return this.titulo
    }
}