package com.example.projetosqlite.repository.sqlite

import com.example.projetonotassqlite.model.Nota

interface NotaRepository {

    fun save(nota: Nota)
    fun remove(nota: Nota)
    fun list(callback:(MutableList<Nota>) -> Unit)
}




