package com.example.projetonotassqlite.views

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.projetonotassqlite.model.Nota
import com.example.projetonotassqlite.adapter.NotaAdapter
import com.example.projetonotassqlite.R
import com.example.projetosqlite.repository.sqlite.SQLiteRepository
import kotlinx.android.synthetic.main.activity_list.*

class ListActivity : AppCompatActivity() {

    private var notas = mutableListOf<Nota>()

    var adapter: NotaAdapter? = null

    private var notasRepository: SQLiteRepository? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        notasRepository = SQLiteRepository(this)

        updateList()

        initRecyclerView()
    }

    private fun list(notas:MutableList<Nota>){
            this.notas  = notas
            //Precisa reavaliar esse código para não criar sempre uma instância do adapter
            adapter = NotaAdapter(
                this.notas,
                this::onNotaItemClick,
                this::onNotaItemLongClick
            )
            rvNotas.adapter = adapter

    }

    private fun updateList(){
        notasRepository?.list { list(it) }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.actions, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if(item.itemId == R.id.nota_add){
            var intent = Intent(this, EditActivity::class.java)
            startActivityForResult(intent,0)
            return true
        }

        return super.onOptionsItemSelected(item)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)


        if(requestCode == 0 && resultCode == Activity.RESULT_OK){

            updateList()
            adapter?.notifyItemInserted(notas.lastIndex)

        }

        if (requestCode == 1 && resultCode == Activity.RESULT_OK){

            updateList()
            adapter?.notifyDataSetChanged()
        }

    }

    fun onNotaItemClick(nota: Nota, posicao: Int){

        var intent = Intent(this, EditActivity::class.java)

        intent.putExtra("nota",nota)
        intent.putExtra("posicao",posicao)

        startActivityForResult(intent,1)

    }

    fun onNotaItemLongClick(nota: Nota, posicao: Int):Boolean{

        notasRepository?.remove(nota)

        updateList()

        adapter?.notifyItemRemoved(posicao)

        return true
    }

    fun initRecyclerView(){

        rvNotas.adapter = adapter

        val layoutMAnager = LinearLayoutManager(this)

        rvNotas.layoutManager = layoutMAnager

    }

}
