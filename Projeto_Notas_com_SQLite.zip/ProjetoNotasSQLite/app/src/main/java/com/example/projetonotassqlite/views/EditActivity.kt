package com.example.projetonotassqlite.views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.example.projetonotassqlite.model.Nota
import com.example.projetonotassqlite.dialog.NotaNameDialog
import com.example.projetonotassqlite.R
import com.example.projetosqlite.repository.sqlite.SQLiteRepository

class EditActivity : AppCompatActivity() {

    private var edtNota: EditText? = null
    private var nota: Nota? = null
    private var posicao: Int? = null

    private var notasRepository: SQLiteRepository? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        edtNota = findViewById(R.id.edt_nota)

        notasRepository = SQLiteRepository(this)

        nota = intent.getSerializableExtra("nota") as Nota?
        posicao = intent.getIntExtra("posicao",-1)

        if (nota != null){
            edtNota?.setText(nota?.conteudo)
        }

    }


    fun gravar(view: View){
        var conteudo: String =  edtNota?.text.toString()

        if (nota == null){


            NotaNameDialog.show(supportFragmentManager,
                object : NotaNameDialog.OnNoteNameSetListener {
                    override fun onNoteNameSet(noteName: String) {
                        salvarConteudoNota(noteName, conteudo)
                    }
                })
        }else{
            var titulo = nota?.titulo.toString()
            var conteudo = edtNota?.text.toString()

            salvarConteudoNota(titulo,conteudo)
        }
    }


    fun salvarConteudoNota(titulo: String, conteudo: String){

        var msg: String = ""

        if (nota == null){
            nota = Nota(titulo, conteudo)

            notasRepository?.save(nota!!)
            msg = "Nota gravada com ID = ${nota?.id}"



        }else{
            nota?.titulo = titulo
            nota?.conteudo = conteudo
            notasRepository?.save(nota!!)

            msg = "Nota atualizada com ID = ${nota?.id}"

        }

        Toast.makeText(this,msg,Toast.LENGTH_LONG).show()
        setResult(RESULT_OK)
        finish()
    }



    fun cancelar(view: View) {
        setResult(RESULT_CANCELED)
        finish()
    }


}
